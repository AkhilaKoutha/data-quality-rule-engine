# Data Quality Rule Base Application

## Installation

```bash
git clone https://github.com/yourusername/data_quality_rule_base.git
cd data_quality_rule_base
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Usage

Configure your rules in a YAML template and run:

```bash
python app/main.py
```

Use the API to process datasets and generate CSV results.

## License

This project is licensed under the MIT License.
