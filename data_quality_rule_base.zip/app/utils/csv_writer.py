import pandas as pd

def write_results_to_csv(results, output_path):
    df = pd.DataFrame(results)
    df.to_csv(output_path, index=False)
