import yaml
import os

def load_yaml_template(dataset_name, base_path="templates"):
    file_path = os.path.join(base_path, f"{dataset_name}.yml")
    with open(file_path, 'r') as file:
        return yaml.safe_load(file)
