from flask import Flask, request, jsonify
from app.utils.yaml_parser import load_yaml_template
from app.utils.rule_engine import execute_rules
from app.utils.csv_writer import write_results_to_csv

app = Flask(__name__)

@app.route("/run_rules", methods=["POST"])
def run_rules():
    data = request.get_json()
    dataset_name = data["dataset_name"]
    csv_output_path = data["csv_output_path"]

    config = load_yaml_template(dataset_name)
    results = execute_rules(config)
    write_results_to_csv(results, csv_output_path)

    return jsonify({"status": "success", "output_file": csv_output_path})

if __name__ == "__main__":
    app.run(debug=True)
